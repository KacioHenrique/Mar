import UIKit
import PlaygroundSupport


var vc = Intro()


vc.preferredContentSize = CGSize(width: 500, height: 500)

PlaygroundSupport.PlaygroundPage.current.liveView = vc //sceneView




