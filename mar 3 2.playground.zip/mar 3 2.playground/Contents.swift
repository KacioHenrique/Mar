import PlaygroundSupport
import SpriteKit



class VC : UIViewController {
  
  override func loadView() {

    // Load the SKScene from 'GameScene.sks'
    let sceneView = SKView(frame: CGRect(x:0 , y:0, width: 500, height: 500))
    if let scene = GameScene(fileNamed: "GameScene") {
      // Set the scale mode to scale to fit the window
      scene.scaleMode = .aspectFill
      // Present the scene
      sceneView.presentScene(scene)
      sceneView.showsNodeCount = true
      sceneView.showsFPS = true
      
      
    }
    
    self.view = sceneView
  }
}

let vc = VC()
vc.preferredContentSize = CGSize(width: 500, height: 500)
PlaygroundSupport.PlaygroundPage.current.liveView = vc //sceneView




