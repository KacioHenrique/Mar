//: A SpriteKit based Playground

import PlaygroundSupport
import SpriteKit

public class GameScene: SKScene {
    
    private var label : SKLabelNode!
    private var spinnyNode : SKShapeNode!
    //imagem do personagem
    let player = SKSpriteNode(imageNamed: "player")
  
    override public func didMove(to view: SKView) {
        backgroundColor = SKColor.blue
        player.position = CGPoint(x: -size.width * 0.2, y: size.height * 0.2)
        let monster = addMonster()
        addChild(player)
        addChild(monster)
      monster.run(SKAction.repeatForever(moves()))
    }
    
    public func touchDown(atPoint pos : CGPoint) {
        guard let n = spinnyNode.copy() as? SKShapeNode else { return }
        
        n.position = pos
        n.strokeColor = SKColor.green
        addChild(n)
    }
    
   public func touchMoved(toPoint pos : CGPoint) {
        guard let n = self.spinnyNode.copy() as? SKShapeNode else { return }
        n.position = pos
        n.strokeColor = SKColor.blue
        addChild(n)
    }
//
//   public func touchUp(atPoint pos : CGPoint) {
//        guard let n = spinnyNode.copy() as? SKShapeNode else { return }
//
//        n.position = pos
//        n.strokeColor = SKColor.red
//        addChild(n)
//    }
//
//    override public func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
//        for t in touches { touchMoved(toPoint: t.location(in: self)) }
//    }
//
//    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
//        for t in touches { touchUp(atPoint: t.location(in: self)) }
//    }
//
//    override public func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
//        for t in touches { touchUp(atPoint: t.location(in: self)) }
//    }
//
//    override public func update(_ currentTime: TimeInterval) {
//        // Called before each frame is rendered
//    }
  func random() -> CGFloat {
    return CGFloat(Float(arc4random()) / 0xFFFFFFFF)
  }
  
  func random(min: CGFloat, max: CGFloat) -> CGFloat {
    return random() * (max - min) + min
  }
  public func moves() -> SKAction {
     let aux = SKAction.sequence([SKAction.moveTo(x: -size.width * 0.2 ,duration: 2),SKAction.moveTo(x:size.width * 0.2 ,duration: 2)])
    //SKAction.removeFromParent()
    return aux
  }
  public func addMonster() -> SKSpriteNode {
        let monster = SKSpriteNode(imageNamed: "monster")
        monster.position = CGPoint(x: random(min: size.width * 0.2, max: size.width), y: random(min: -size.width * 0.2, max: size.height * 0.2 ))
      return monster
    }
}
