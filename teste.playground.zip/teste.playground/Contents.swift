//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

class MyViewController : UIViewController {
    let label = UILabel()
    var i = 0
    override func loadView() {
        let view = UIView()
        view.frame = CGRect(x: 0, y: 0, width: 500, height: 500)
        view.backgroundColor = .white
        label.lineBreakMode = .byWordWrapping
        label.numberOfLines = -1
        label.frame = CGRect(x: 60, y: 200, width: 200, height: 80)
        label.text = "You have been chosen to save the ocean, of acid bubbles"
        label.textColor = .black
        let botton = UIButton()
        botton.frame = CGRect(x: 280, y: 450, width: 80, height: 30)
        botton.backgroundColor = #colorLiteral(red: 0.9254902005, green: 0.2352941185, blue: 0.1019607857, alpha: 1)
        botton.setTitle("Pass", for: .normal)
      botton.addTarget(self, action: #selector(history), for: .touchDown)
        view.addSubview(botton)
        view.addSubview(label)
        self.view = view
     
  }
  
  @objc func history(){
    i += 1
    if(i == 1){
      label.text = "Now you need fast "
    }
    if(i == 2){
      label.text = "you have a submarine and missile"
    }
    if(i == 3){
      label.text = "tap to shoot the missile and run against time "
    }
  }
  
}
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()
