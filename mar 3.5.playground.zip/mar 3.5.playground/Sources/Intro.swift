//: A UIKit based Playground for presenting user interface

import UIKit
import PlaygroundSupport
import AVFoundation
public class Intro : UIViewController {
  let label = UILabel()
  var i = 0
    let botton = UIButton()
    override public func loadView() {
        let view = UIView()
        view.frame = CGRect(x: 0, y: 0, width: 1000, height:1000)
        let backgroundImage = UIImageView(frame: view.frame)
        backgroundImage.image = UIImage(named: "intro.jpg")
        view.addSubview(backgroundImage)
        view.backgroundColor = .blue
        creatImage(view)
        label.lineBreakMode = .byWordWrapping
        label.numberOfLines = -1
        label.frame = CGRect(x: 240, y: 200, width: 200, height: 80)
        label.text = "You have been chosen to save the ocean, of bubble of oil and acid"
        label.textColor = .black
        //let botton = UIButton()
        botton.frame = CGRect(x: 280, y: 400, width: 200, height: 60)
        botton.backgroundColor = #colorLiteral(red: 0.9686274529, green: 0.78039217, blue: 0.3450980484, alpha: 1)
        botton.setTitle("NEXT", for: .normal)
        botton.addTarget(self, action: #selector(history), for: .touchDown)
        
        view.addSubview(botton)
        view.addSubview(label)
        self.view = view
    
  }
    public func creatImage(_ view:UIView){
        let turtle = UIImage(named:"turtle")
        let turtleView = UIImageView(image: turtle!)
        turtleView.frame = CGRect(x: 60,y: 300,width : 200, height: 200)
        view.addSubview(turtleView)
        let ball = UIImage(named:"ball")
        let ballView = UIImageView(image: ball!)
        ballView.frame = CGRect(x: 180,y: 160,width: 300, height: 150)
        view.addSubview(ballView)
    }
  @objc func history(){
    i += 1
    
    if(i == 1){
      label.text = "Now you need to be fast "
    }
    else if(i == 2){
      label.text = "you have a submarine and torpedos"
    }
    else if(i == 3){
      label.text = "tap to shoot the missile and run against time "
        self.botton.backgroundColor = #colorLiteral(red: 0.7450980544, green: 0.1568627506, blue: 0.07450980693, alpha: 1)
        self.botton.setTitle("PLAY", for: .normal)
    }
    else if(i == 4){
     
        let vc = VC()
      
      vc.preferredContentSize = CGSize(width: 500, height: 500)
      //vc.frame(CGRect(x: 0,y: 0,width: 500,height: 500))
      self.present(vc, animated: false)
    }
  }
  
}
// Present the view controller in the Live View window
//PlaygroundPage.current.liveView = kacio()


