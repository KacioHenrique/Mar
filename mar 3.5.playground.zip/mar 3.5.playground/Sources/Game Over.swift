import Foundation
import SpriteKit

class GameOverScene: SKScene {
  
  init(size: CGSize, won:Bool) {
    
    super.init(size: size)
    let resut:SKSpriteNode
    let label = SKLabelNode(fontNamed : "Chalkduster")
    let label2 = SKLabelNode(fontNamed : "Chalkduster")
    if won {
        resut = SKSpriteNode(imageNamed: "oceano")
        label.text = "YOU WON !"
        label.fontColor = SKColor.yellow
        label2.text = "You saved the ocean"
        label2.fontColor = label.fontColor
    }
    else {
      resut = SKSpriteNode(imageNamed: "dark2")
        label.text = "YOU LOSE"
        label.fontColor = SKColor.red
        label2.text = "ocean it's over"
        label2.fontColor = label.fontColor
    }
    resut.position = CGPoint(x: size.width/2, y: size.height/2)
    label.fontSize = 100
    label.position = CGPoint(x: size.width/2, y: size.height/2)
    label2.fontSize = 80
    label2.position = CGPoint(x: size.width/2, y: size.height/2-label2.fontSize)
    addChild(resut)
    addChild(label)
    addChild(label2)
}
  
  // 6
  required init(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
}
